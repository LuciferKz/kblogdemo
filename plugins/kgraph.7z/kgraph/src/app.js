import KGraph from './js/kgraph/KGraph';

window.KGraph = KGraph;